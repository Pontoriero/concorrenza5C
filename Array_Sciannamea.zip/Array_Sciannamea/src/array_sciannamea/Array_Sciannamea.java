package array_sciannamea;



public class Array_Sciannamea {

    public static void main(String[] args) {
        
    }
    
}
