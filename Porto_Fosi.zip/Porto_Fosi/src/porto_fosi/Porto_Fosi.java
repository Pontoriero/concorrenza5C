/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package porto_fosi;

/**
 *
 * @author verifica
 */
public class Porto_Fosi {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        /*
        Porto navi= new Porto();
        Navi p1=new Navi("nazionale",1);
        Navi p2=new Navi("nazionale",2);
        Navi p3=new Navi("nazionale",3);
        Navi p4=new Navi("nazionale",4);
        Navi p5=new Navi("nazionale",5);
        Navi p6=new Navi("internazionale",6);
        Navi p7=new Navi("internazionale",7);
        Navi p8=new Navi("internazionale",8);
        Navi p9=new Navi("internazionale",9);
        Navi p10=new Navi("internazionale",10);
        
        p1.start();
        p2.start();
        
    */    
    }
    
}
