package array_lugari;

/**
 *
 * @author verifica
 */
public class Thread1 {

    public Thread1() {
        
    }
    
}
