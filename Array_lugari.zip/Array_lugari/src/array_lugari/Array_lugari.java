package array_lugari;

/**
 *
 * @author verifica
 */
public class Array_lugari {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int N=(int) (Math.random()*100);
        int[] arrSt= new int[N];
        
        for (int i = 0; i < N; i++) {
            int K=(int) (Math.random()*2+3);
            arrSt[i]=K;
        }
        
        for (int i = 0; i < K; i++) {
            new Thread1;
            
        }
        
        
        
        
    }
    
}
