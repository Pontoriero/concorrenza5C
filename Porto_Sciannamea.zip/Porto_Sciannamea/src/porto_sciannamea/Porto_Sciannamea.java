package porto_sciannamea;

public class Porto_Sciannamea {


    public static void main(String[] args) {
        
        int id = (int) (Math.random()*10+1);
        Boolean n=true;
        
        
    }


    
}
